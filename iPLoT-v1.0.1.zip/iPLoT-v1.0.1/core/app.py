"""模組看得到的全部：每次執行新建一個 App，傳給模組的 run(app)。"""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import TYPE_CHECKING, Any

from . import __version__, scan
from .types import Config, ModuleInfo, Result

if TYPE_CHECKING:
    from .core import Core


class App:
    """模組拿到的 app。介面只加不減；要拿掉東西就升 api_version 並寫進 CHANGELOG
    （1 是第一版；2 拿掉了 window，見 D66；3 加了 config、version、page；4 加了 parent、children；
    5 加了 call、each、providers，以及「沒有的名字交給提供 app.<名字> 的模組」，見 D159；
    6 每按一次另開一個程序跑，加了 start，模組可以寫 MIN_API，見 D161；7 加了 top_modules、parent_of、children_of、panel、describe，
    模組不用再 import 核心或猜自己在哪個面板，見 D164）。version 是核心的版本字串。"""

    api_version: int = 7
    version: str = __version__

    def __init__(self, core: Core, info: ModuleInfo) -> None:
        self._core, self._info = core, info
        self._memory = core.memories.setdefault(info.folder, {})

    def __getattr__(self, name: str) -> Any:
        """app 上沒有的名字：有模組宣告提供 app.<name>，app.<name>(…) 就交給它執行（D159）；沒有就是 AttributeError，
        所以 hasattr(app, "x") 照樣看得出有沒有這個功能。新功能不用改核心：寫一個提供它的模組。"""
        if name.startswith("_") or not self._core.providers("app." + name):
            raise AttributeError(name)
        return lambda *args: self._core.call("app." + name, *args)

    def call(self, role: str, *args: Any) -> Any:
        """交給第一個提供 role 的模組（PROVIDES 宣告的），回它的回傳值；沒有提供者回 None。"""
        return self._core.call(role, *args)

    def each(self, role: str, *args: Any) -> list[tuple[ModuleInfo, Any]]:
        """交給每一個提供 role 的模組，回（模組, 回傳值）的清單。"""
        return self._core.each(role, *args)

    def providers(self, role: str) -> tuple[ModuleInfo, ...]:
        """提供 role 的模組，依掃描順序。"""
        return tuple(self._core.providers(role))

    @property
    def module(self) -> ModuleInfo:
        """正在執行的模組的資訊：name、title、folder、file 等（見附錄 B 的 ModuleInfo）。"""
        return self._info

    @property
    def home(self) -> Path:
        """iPLoT 程式資料夾。"""
        return self._core.home

    @property
    def modules(self) -> tuple[ModuleInfo, ...]:
        """目前範圍內所有模組的唯讀清單。"""
        return self._core.all_modules()

    @property
    def parent(self) -> ModuleInfo | None:
        """這個模組的父層模組（資料夾上一層，不越過根目錄）；最上層的模組沒有，回 None。可以直接交給 app.run。"""
        return self.parent_of(self._info)

    @property
    def children(self) -> tuple[ModuleInfo, ...]:
        """這個模組的子模組，每次都重新看磁碟；跟面板進到下一層時看到的一樣。可以直接交給 app.run。"""
        return self.children_of(self._info)

    def top_modules(self) -> tuple[ModuleInfo, ...]:
        """每個根目錄最上層的模組，每次都重新看磁碟；不管面板現在停在哪一層（app.modules 是面板現在那一層）。"""
        return tuple(m for g in scan.find_modules(self._core.roots()) for m in g.modules)

    def parent_of(self, info: ModuleInfo) -> ModuleInfo | None:
        """任何一個模組的父層（跟 app.parent 一樣的規則）；例如導覽列替開頁面的模組畫「上一層」。"""
        return scan.parent_of(info, self._core.roots())

    def children_of(self, info: ModuleInfo) -> tuple[ModuleInfo, ...]:
        """任何一個模組的子模組（跟 app.children 一樣的規則）。"""
        return tuple(scan.find_children(info.folder, info.root))

    @property
    def panel(self) -> str | None:
        """開這個模組的面板說它是哪一種（例如「網頁」「tkinter」）；不是從面板開的（python3 main.py --run）是 None。"""
        return getattr(self._core.view, "name", None)  # 面板說自己是哪一種；工作程序裡是開它的那個面板的（D164）

    def describe(self, error: Any) -> str:
        """一筆錯誤（有 kind、message、file、line、source、module 的物件）的白話一句，跟面板訊息區說的一樣。"""
        return self._core.describe(error)

    @property
    def config(self) -> Config:
        """config.py 讀出來的設定（唯讀）：roots、editor、history_keep、update_url、workshop_url。"""
        return self._core.config

    @property
    def memory(self) -> dict:
        """這個模組自己的 dict，iPLoT 開著期間保留；跨次啟動要留的請寫成檔案放 module.folder。"""
        return self._memory

    def log(self, text: str) -> None:
        """寫一行到面板下方的訊息區。"""
        self._core.view.log(text)

    # 以下五個動作交給 modules/作業系統 執行（core.action）。那個模組執行時工作目錄是它自己的資料夾，
    # 所以路徑在這裡先變成絕對的：相對路徑指的是呼叫的模組自己的資料夾，跟 open("x.txt") 一樣

    def open(self, path: Path) -> None:
        """打開：資料夾用檔案總管、檔案用預設程式。由 modules/作業系統 執行。"""
        self._core.action("open", Path(path).absolute())

    def edit(self, path: Path, line: int | None = None) -> None:
        """用 config.py 的 EDITOR 打開檔案（None 時用系統預設文字編輯器）；資料夾改用 open。"""
        self._core.action("edit", Path(path).absolute(), self._core.config.editor, line)

    def reveal(self, path: Path) -> None:
        """在檔案總管裡顯示並選取這個檔案或資料夾。"""
        self._core.action("reveal", Path(path).absolute())

    def restart(self) -> None:
        """請面板關掉、整個 iPLoT 從頭再來，啟動參數照舊（D166）。不是面板開的（main.py --run）丟 AttributeError。"""
        self._core.view.restart()

    def terminal(self, path: Path) -> None:
        """在終端機打開這個資料夾。"""
        self._core.action("terminal", Path(path).absolute())

    def trash(self, path: Path) -> Path | None:
        """搬到系統垃圾桶，永遠不直接刪除；回傳搬到哪裡（Windows 的資源回收筒沒有路徑，回 None）。"""
        return self._core.action("trash", Path(path).absolute())

    def run(self, name: str | ModuleInfo) -> Result:
        """執行另一個模組：先找面板目前這一層，找不到再找最上層；同一處有兩個同名就丟 LookupError，不猜。"""
        return self._core.run_by_name(name)

    def start(self, name: ModuleInfo) -> None:
        """開始跑另一個模組，不等它跑完（它在自己的程序裡跑，頁面開著也不卡）；要等結果用 run。"""
        self._core.start(name)

    def rescan(self) -> None:
        """重新掃描並重畫面板；在模組執行中呼叫時，會等這次執行結束後才做。"""
        self._core.rescan()

    def ask(self, prompt: str, default: str = "") -> str | None:
        """跳出對話框問一個字串；按取消回 None。"""
        return self._core.view.ask(prompt, default)

    def confirm(self, prompt: str) -> bool:
        """跳出對話框問「確定／取消」；按確定回 True。"""
        return self._core.view.confirm(prompt)

    def page(self, title: str, html: str, api: object | None = None) -> None:
        """開一個視窗顯示一頁 HTML，關掉才回來；api 的公開方法給那一頁的 JS 用 pywebview.api.<方法> 呼叫。
        模組在自己的程序裡跑時（D161），交給提供 app.page 的模組在這個程序開視窗，只卡住自己；
        tkinter 面板（安全模式與備用面板）沒有頁面，只在訊息區記一行。"""
        if getattr(self._core, "remote", None) is not None and self._core.providers("app.page"):
            self._paging(True)
            try:
                return self._core.call("app.page", title, html, api, self._info)
            finally:
                self._paging(False)
        return self._core.view.page(title, html, api)

    def _paging(self, opened: bool) -> None:
        with contextlib.suppress(Exception):  # 面板的狀態列說「頁面開著」，不說「執行中」（D166）；沒有這個方法的面板不管
            self._core.view.paging(self._info.title, opened)

    def choose_files(self) -> list[Path]:
        """跳出檔案選擇視窗；按取消回空清單。"""
        return self._core.view.choose_files()

    def choose_folder(self) -> Path | None:
        """跳出資料夾選擇視窗；按取消回 None。"""
        return self._core.view.choose_folder()
