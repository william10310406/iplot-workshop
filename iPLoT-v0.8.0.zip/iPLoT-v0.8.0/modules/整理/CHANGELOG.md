# Changelog

「整理」這個模組的版本紀錄，格式跟 iPLoT 的 CHANGELOG.md 一樣（[Keep a Changelog](https://keepachangelog.com/zh-TW/1.1.0/)）。`tools/publish.py` 取最上面那一節的版本號當工作坊裡的版本，取那一節的第一段當清單頁上的「這一版」。

## [Unreleased]

## [0.1.0] - 2026-11-23

面板上的右鍵「改名…」「移到垃圾桶…」從核心搬到這個模組（D159）。規則跟 0.7.4 一樣：只動自己新增的模組，隨附的、從工作坊裝來的有保護，刪除一律進系統的垃圾桶。
