"""在終端機打開 iPLoT 資料夾。一行 app.terminal；想看不用 app、直接用標準庫的寫法，看「重新啟動」。"""
ICON = "⌨️"


def run(app):
    app.terminal(app.home)
