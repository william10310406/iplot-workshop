import builtins
import os
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

from conftest import FakeCore, FakeView, make_module

from core.app import App
from core.runner import run_module
from core.scan import module_info
from core.text import T
from core.types import DEFAULT_CONFIG


def mod(home, src, name="A"):
    folder = make_module(home / "modules", name, src)
    return module_info(folder, home / "modules", "here")


def test_calls_run_with_app(home):
    app = SimpleNamespace(seen=[])
    r = run_module(mod(home, "def run(app):\n    app.seen.append(app)\n"), app)
    assert r.ok and r.error is None and app.seen == [app]


def test_fresh_namespace_each_press(home):
    info = mod(home, "def run(app):\n    assert 'FLAG' not in globals()\n    globals()['FLAG'] = 1\n")
    assert run_module(info, None).ok
    assert run_module(info, None).ok


def test_sees_file_changes(home):
    app = SimpleNamespace(seen=[])
    info = mod(home, "def run(app):\n    app.seen.append(1)\n")
    run_module(info, app)
    info.file.write_text("def run(app):\n    app.seen.append(2)\n", encoding="utf-8")
    run_module(info, app)
    assert app.seen == [1, 2]


def test_missing_run_is_not_an_error(home):
    r = run_module(mod(home, "def on_files(app, paths):\n    pass\n"), None)
    assert r.ok and r.error is None


def test_exception_has_file_and_line(home):
    info = mod(home, "def run(app):\n    x = 1\n    1/0\n")
    r = run_module(info, None)
    assert (r.ok, r.error.file, r.error.line, r.error.kind) == (False, info.file, 3, "ZeroDivisionError")


def test_syntax_error_reported(home):
    r = run_module(mod(home, "x = 1\ndef run(app)\n    pass\n"), None)
    assert (r.ok, r.error.kind, r.error.line) == (False, "SyntaxError", 2)


def test_exit_is_error_not_fatal(home):
    info = mod(home, "def run(app):\n    exit(1)\n")
    r = run_module(info, None)
    assert (r.ok, r.error.kind) == (False, "SystemExit")
    assert r.error.message == T["module_exit"].format(code=1) == "模組以 exit(1) 結束"
    assert (r.error.file, r.error.line) == (info.file, 2)


def test_exit_zero_is_ok(home):
    # python3 iplot.py 跑到 exit() 是正常結束，狀態 0（D49）
    for src in ('print("a")\nexit()\n', 'import sys\nprint("a")\nsys.exit(0)\n', 'print("a")\nquit()\n'):
        r = run_module(mod(home, src), None)
        assert (r.ok, r.error, r.output) == (True, None, "a\n"), src


def test_on_files_handler(home):
    app = SimpleNamespace(seen=[])
    info = mod(home, "def on_files(app, paths):\n    app.seen.extend(paths)\n")
    r = run_module(info, app, "on_files", ([Path("a")],))
    assert r.ok and app.seen == [Path("a")]


def test_print_is_captured(home):
    r = run_module(mod(home, "def run(app):\n    print('hi')\n"), None)
    assert r.output == "hi\n"


def test_null_byte_reported_not_raised(home):
    folder = make_module(home / "modules", "A")
    (folder / "iplot.py").write_bytes(b"x = 1\x00\n")
    r = run_module(module_info(folder, home / "modules", "here"), None)
    assert not r.ok and r.error.file == folder / "iplot.py"


def test_eval_syntax_error_points_at_module_line(home):
    info = mod(home, "def run(app):\n    x = 1\n    eval('1+')\n")
    r = run_module(info, None)
    assert (r.error.kind, r.error.file, r.error.line) == ("SyntaxError", info.file, 3)


def test_stderr_is_captured_too(home):
    src = "import sys\ndef run(app):\n    print('out')\n    sys.stderr.write('err\\n')\n"
    assert run_module(mod(home, src), None).output == "out\nerr\n"


# ── 腳本語意（M1.2，D47）：按下 ＝ 在模組自己的資料夾裡執行 python3 iplot.py ──


def test_main_guard_runs(home):
    r = run_module(mod(home, 'if __name__ == "__main__":\n    print("main")\n'), None)
    assert r.output == "main\n"


def test_cwd_is_module_folder_and_restored(home):
    before = os.getcwd()
    info = mod(home, 'open("x.txt", "w").write("1")\n')
    run_module(info, None)
    assert (info.folder / "x.txt").exists()
    assert os.getcwd() == before


def test_sys_argv_is_module_file(home):
    before = sys.argv
    info = mod(home, "import sys\nprint(sys.argv)\n")
    r = run_module(info, None)
    assert r.output == f"{[str(info.file)]}\n"
    assert sys.argv is before


def test_sibling_import_reloads_after_edit(home, monkeypatch):
    # 同一秒內改成同樣大小的內容，舊的 .pyc 會被當成有效：執行期間不寫 .pyc 才保證重讀
    monkeypatch.setattr(sys, "dont_write_bytecode", False)
    info = mod(home, "import helper\nprint(helper.V)\n")
    (info.folder / "helper.py").write_text("V = 1\n", encoding="utf-8")
    assert run_module(info, None).output == "1\n"
    (info.folder / "helper.py").write_text("V = 2\n", encoding="utf-8")
    assert run_module(info, None).output == "2\n"


def test_purge_spares_modules_loaded_before_the_run(home, monkeypatch):
    # iPLoT 放在某個模組的資料夾裡時，core 自己的 __file__ 也在那個資料夾底下：不能被清掉
    info = mod(home, "x = 1\n")
    early = ModuleType("early")
    early.__file__ = str(info.folder / "early.py")
    monkeypatch.setitem(sys.modules, "early", early)
    run_module(info, None)
    assert sys.modules.get("early") is early


def test_toplevel_script_without_run_is_ok(home):
    r = run_module(mod(home, 'print("hi")\n'), None)
    assert (r.ok, r.error, r.output) == (True, None, "hi\n")


def test_on_files_missing_still_errors(home):
    r = run_module(mod(home, 'print("hi")\n'), None, "on_files", ([Path("a")],))
    assert not r.ok and r.error.kind == "MissingHandler"


def test_input_becomes_dialog(home, fake_core):
    fake_core.view.answer = "10"
    info = mod(home, 'x = input("年齡")\nprint(x)\n')
    r = run_module(info, App(fake_core, info))
    assert (r.output, r.error) == ("10\n", None)
    assert fake_core.view.asks == ["年齡"]


def test_input_cancel_raises_eoferror(home, fake_core):
    # 真的 input() 在鍵盤關掉（Ctrl-D）時就是 EOFError（D49）
    fake_core.view.answer = None
    info = mod(home, 'print("hi")\nx = input("年齡")\nprint(x)\n')
    r = run_module(info, App(fake_core, info))
    assert (r.ok, r.error.kind, r.error.message) == (False, "EOFError", T["input_cancelled"])
    assert (r.error.file, r.error.line, r.output) == (info.file, 2, "hi\n")


def test_validation_loop_exits_on_cancel(home, fake_core):
    # 課本的驗證迴圈：取消要是回空字串，int("") 是 ValueError，永遠出不去
    fake_core.view.answer = None
    src = 'while True:\n    try:\n        n = int(input("數字"))\n        break\n    except ValueError:\n        pass\n'
    info = mod(home, src)
    r = run_module(info, App(fake_core, info))
    assert (r.ok, r.error.kind, r.error.line) == (False, "EOFError", 3)
    assert len(fake_core.view.asks) == 1


def test_module_can_catch_cancel(home, fake_core):
    fake_core.view.answer = None
    info = mod(home, 'try:\n    x = input("q")\nexcept EOFError:\n    x = "預設"\nprint(x)\n')
    r = run_module(info, App(fake_core, info))
    assert (r.ok, r.error, r.output) == (True, None, "預設\n")


def test_env_restored_after_error(home, fake_core):
    def env():
        return os.getcwd(), sys.argv, builtins.input, list(sys.path), sys.dont_write_bytecode

    before = env()
    info = mod(home, 'raise ValueError("boom")\n')
    r = run_module(info, App(fake_core, info))
    assert r.error.kind == "ValueError"
    assert env() == before


def test_exit_after_exit_env_restored(home, fake_core):
    def env():
        return os.getcwd(), sys.argv, builtins.input, list(sys.path), sys.dont_write_bytecode

    before = env()
    info = mod(home, 'print("a")\nexit()\n')
    r = run_module(info, App(fake_core, info))
    assert (r.ok, r.output) == (True, "a\n")
    assert env() == before


def test_input_in_helper_also_dialog(home, fake_core):
    fake_core.view.answer = "yes"
    info = mod(home, "import helper\nprint(helper.f())\n")
    (info.folder / "helper.py").write_text('def f():\n    return input("q")\n', encoding="utf-8")
    r = run_module(info, App(fake_core, info))
    assert (r.output, r.error, fake_core.view.asks) == ("yes\n", None, ["q"])


# ── 最終審查的修正 ──


def test_helper_in_subfolder_reloads_after_edit(home, monkeypatch):
    # utils/ 沒有 __init__.py 時是 namespace package：沒有 __file__，要看 __path__ 才清得掉
    monkeypatch.setattr(sys, "dont_write_bytecode", False)
    info = mod(home, "from utils import tools\nprint(tools.V)\n")
    (info.folder / "utils").mkdir()
    (info.folder / "utils" / "tools.py").write_text("V = 1\n", encoding="utf-8")
    assert run_module(info, None).output == "1\n"
    (info.folder / "utils" / "tools.py").write_text("V = 2\n", encoding="utf-8")
    assert run_module(info, None).output == "2\n"
    assert "utils" not in sys.modules


def test_nested_run_gets_its_own_helper(home):
    # A 的 helper.py 已經 import 了，A 再用 app.run 跑 B：B 的 import helper 要拿到 B 自己的
    a = mod(home, "import helper\ndef run(app):\n    app.run('B')\n    print(helper.NAME)\n", "A")
    b = mod(home, "import helper\nprint(helper.NAME)\n", "B")
    (a.folder / "helper.py").write_text("NAME = 'A-helper'\n", encoding="utf-8")
    (b.folder / "helper.py").write_text("NAME = 'B-helper'\n", encoding="utf-8")
    inner = []
    app = SimpleNamespace(run=lambda name: inner.append(run_module(b, None).output))
    r = run_module(a, app)
    assert (inner, r.output, r.error) == (["B-helper\n"], "A-helper\n", None)
    assert "helper" not in sys.modules


def test_dialog_shows_what_was_printed_since_last_question(home, fake_core):
    # 猜數字這種腳本：print("太大") 之後再 input()，回饋要在下一個對話框裡看得到
    fake_core.view.answer = "50"
    src = 'x = input("猜一個數字")\nprint("太大")\ny = input("再猜")\nprint("請按確定")\ninput()\n'
    info = mod(home, src)
    r = run_module(info, App(fake_core, info))
    assert fake_core.view.asks == ["猜一個數字", "太大\n再猜", "請按確定"]
    assert (r.output, r.error) == ("太大\n請按確定\n", None)


def test_handler_return_value_in_result(home):
    info = module_info(make_module(home / "modules", "A", "def run(app):\n    return 42\n"), home / "modules", "here")
    assert run_module(info, App(FakeCore(home, DEFAULT_CONFIG, FakeView()), info)).value == 42


def test_on_files_return_value_and_missing_run_is_none(home):
    src = "def on_files(app, paths):\n    return len(paths)\n"
    info = module_info(make_module(home / "modules", "B", src), home / "modules", "here")
    app = App(FakeCore(home, DEFAULT_CONFIG, FakeView()), info)
    assert run_module(info, app, "on_files", (["a", "b"],)).value == 2
    assert run_module(info, app).value is None
